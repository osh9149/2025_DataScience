import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np
df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
plt.scatter(df['총계 남'], df['총계 여'])
x = np.array(df['총계 남']).reshape(-1, 1)
y = np.array(df['총계 여']).reshape(-1, 1)

model = LinearRegression().fit(x, y)

plt.scatter(model.predict(x), model.predict(x)-y )
plt.hlines(y=0, xmin=-100, xmax=25000, color='red') 