# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 21:36:22 2019

@author: 
"""

import numpy as np
a=np.array([1,2,3,4,5])
avg=np.mean(a)
print(avg)