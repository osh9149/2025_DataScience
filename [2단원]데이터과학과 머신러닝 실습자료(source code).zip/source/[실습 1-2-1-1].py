import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('2019_03_Daegu_Average_Temperature.csv', encoding = "cp949")
plt.bar(range(1, 32), df['평균기온(°C)'])