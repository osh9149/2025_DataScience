import pandas as pd
from scipy import stats 
import seaborn as sns 

df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
sns.distplot(df['총계'], fit=stats.norm)
