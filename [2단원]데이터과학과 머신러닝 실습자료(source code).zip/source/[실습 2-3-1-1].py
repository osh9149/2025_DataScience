import pandas as pd

lst=['What','a','wonderful','world']
print(lst)
df=pd.DataFrame(lst)
print(df)