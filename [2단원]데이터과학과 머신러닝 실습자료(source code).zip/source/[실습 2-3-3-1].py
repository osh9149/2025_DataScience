import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")

x = np.array(df['중구 남']).reshape(-1, 1)
y = np.array(df['동구 여']).reshape(-1, 1)

model = LinearRegression().fit(x, y)
print("기울기 :", model.coef_, "절편 :", model.intercept_)
b0 = model.intercept_[0] #절편
b1 = model.coef_[0][0] #기울기
plt.plot(x, b0 + b1*x )

