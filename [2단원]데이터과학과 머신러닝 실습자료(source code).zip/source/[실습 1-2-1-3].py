import pandas as pd

df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
print("범위 : ", max(df['총계'])-min(df['총계']))
print("사분위간 범위 : ",  df['총계'].quantile(0.75)- df['총계'].quantile(0.25))