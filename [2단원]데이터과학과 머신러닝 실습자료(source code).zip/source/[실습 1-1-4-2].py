# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 12:20:13 2019

@author:  
"""
import pandas as pd

df=pd.read_csv('./data/toilet_2019.csv', encoding = "cp949")
print(df)
print(pd.value_counts(df['남성용-소변기수']))