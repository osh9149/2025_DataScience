import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
plt.scatter(df['총계 남'], df['총계 여'])

b0 = model.intercept_[0] #절편
b1 = model.coef_[0][0] #기울기
plt.plot(x, b0 + b1*x, 'r' )
