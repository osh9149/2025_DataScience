import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")

print("피어슨 상관계수 :", df['총계 남'].corr(df['총계 여'], method="pearson"))
print("스피어만 상관계수 :", df['총계 남'].corr(df['총계 여'], method="spearman"))
print("켄들 상관계수 :", df['총계 남'].corr(df['총계 여'], method="kendall"))

