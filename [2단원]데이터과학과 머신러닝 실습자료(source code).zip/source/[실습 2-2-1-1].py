import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
print(df)
plt.scatter(df['총계 남'], df['총계 여'])
