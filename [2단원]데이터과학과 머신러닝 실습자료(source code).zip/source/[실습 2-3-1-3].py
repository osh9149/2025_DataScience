import pandas as pd

dic1={'이름':['Kim','Lee','Park'],
      '학년':[3,2,1],
      '학번':[3301,2103,1101]
      }
print(dic1)
df=pd.DataFrame(dic1)
print(df)
