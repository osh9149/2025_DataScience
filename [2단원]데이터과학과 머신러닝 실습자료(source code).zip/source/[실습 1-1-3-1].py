import pandas as pd

df = pd.read_csv('./data/toilet_2019.csv', encoding = "cp949")
print("남성용-소변기수 중앙값 : ", df['남성용-소변기수'].quantile(0.5))