# -*- coding: utf-8 -*-
"""
pandas
"""

import pandas as pd

df=pd.read_csv('./data/toilet_2019.csv', encoding = "cp949")

print('평균 남성용 소변기수 : ', df['남성용-소변기수'].mean())


