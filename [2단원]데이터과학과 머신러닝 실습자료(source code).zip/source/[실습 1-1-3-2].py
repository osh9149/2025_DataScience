import pandas as pd

df = pd.read_csv('./data/toilet_2019.csv', encoding = "cp949")
print("하위 25% : ", df['남성용-소변기수'].quantile(0.25))
print("중앙값 : ", df['남성용-소변기수'].quantile(0.5))
print("상위 25% : ", df['남성용-소변기수'].quantile(0.75))