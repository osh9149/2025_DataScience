# -*- coding: utf-8 -*-
"""
결과 예시
li :  [3, 4, 9, 7, 1]
arr :  [3 4 9 7 1]
"""
import numpy as np
import random as rd

li=[]

for i in range(5):
    li.append(rd.randint(1,10))
print('li : ',li) #5개의 저장된 숫자 출력

arr=np.array(li)
print('arr : ', arr)

avg=arr.mean()
print('avg : ', avg)

#avg=np.mean(arr)
#print('avg : ', avg)
