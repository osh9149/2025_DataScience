import pandas as pd

lst1=['What','a','wonderful','world']
lst2=['What','a','beautiful','world']
lst=[lst1,lst2]
print(lst)
df=pd.DataFrame(lst)
print(df)