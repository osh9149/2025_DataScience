import pandas as pd

df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
print("나이 : ", df['총계'].idxmax(),"세")
print("인구수 : ", df['총계'].max(),"명")
