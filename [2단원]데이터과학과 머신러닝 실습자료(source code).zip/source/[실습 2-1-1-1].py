import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
path='NanumGothic.ttf'
fontprop=fm.FontProperties(fname=path, size=18)
df = pd.read_csv('2019_03_Daegu_Average_Temperature.csv', encoding = "cp949")
plt.hist(df['평균기온(°C)'])
plt.title("평균 기온",fontproperties=fontprop)
plt.xlabel("일",fontproperties=fontprop)
plt.ylabel("온도",fontproperties=fontprop)
