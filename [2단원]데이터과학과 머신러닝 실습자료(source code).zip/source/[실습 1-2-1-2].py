import pandas as pd
import matplotlib.pyplot as plt
plt.title('Population')
plt.xlabel('Age')
plt.ylabel('Number')
df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")
plt.bar(range(0,101 ), df['총계'])
