# -*- coding: utf-8 -*-
"""
Created on Fri Oct 11 21:09:54 2019

@author: 
"""

data = [1, 3, 5, 7, 9]
avg = sum(data) / len(data)
print("평균 : ", avg)