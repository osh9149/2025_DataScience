# -*- coding: utf-8 -*-
"""
Created on Sun Oct 13 18:41:51 2019

@author: 김동균
"""

import pandas as pd

df=pd.read_csv('./data/toilet_2019.csv', encoding = "cp949")

print('평균 남성용 대변기수 : ', df['남성용-대변기수'].mean())
print('평균 여성용 대변기수 : ', df['여성용-대변기수'].mean())
print('평균 남성용-장애인용 대변기수 : ',#줄바꿈
      df['남성용-장애인용대변기수'].mean())
print('평균 여성용-장애인용 대변기수 : ',
      df['여성용-장애인용대변기수'].mean())

