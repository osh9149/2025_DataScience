import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

df = pd.read_csv('./data/population_2019.csv', encoding = "cp949")

x = np.array(df['총계 남']).reshape(-1, 1)
y = np.array(df['총계 여']).reshape(-1, 1)

model = LinearRegression().fit(x, y)
print("기울기 :", model.coef_, "절편 :", model.intercept_)

